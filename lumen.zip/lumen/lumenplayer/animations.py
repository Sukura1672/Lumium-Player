"""Small reusable animation helpers."""

from __future__ import annotations

from PySide6.QtCore import QEasingCurve, QObject, QPropertyAnimation, Signal
from PySide6.QtWidgets import QGraphicsOpacityEffect, QWidget

from .constants import FADE_DURATION_MS, SLIDE_DURATION_MS


class OpacityFader(QObject):
    """Fades a widget in and out through a graphics opacity effect."""

    def __init__(
        self,
        widget: QWidget,
        duration_ms: int = FADE_DURATION_MS,
        hide_when_transparent: bool = False,
    ) -> None:
        super().__init__(widget)
        self._widget = widget
        self._hide_when_transparent = hide_when_transparent
        self._target = 1.0
        self._effect = QGraphicsOpacityEffect(widget)
        widget.setGraphicsEffect(self._effect)
        self._animation = QPropertyAnimation(self._effect, b"opacity", self)
        self._animation.setDuration(duration_ms)
        self._animation.setEasingCurve(QEasingCurve.InOutCubic)
        self._animation.finished.connect(self._on_finished)

    @property
    def target_visible(self) -> bool:
        """True when the widget is visible or on its way to becoming visible."""
        return self._target > 0.0

    def fade_in(self) -> None:
        self._widget.show()
        self._animate_to(1.0)

    def fade_out(self) -> None:
        self._animate_to(0.0)

    def flash_in(self, start_opacity: float = 0.0) -> None:
        """Restarts the widget from ``start_opacity`` and fades it to full."""
        self._animation.stop()
        self._effect.setOpacity(start_opacity)
        self._animate_to(1.0)

    def snap(self, visible: bool) -> None:
        """Jumps to the final state without animating."""
        self._animation.stop()
        self._target = 1.0 if visible else 0.0
        self._effect.setOpacity(self._target)
        self._widget.setVisible(visible or not self._hide_when_transparent)

    def _animate_to(self, value: float) -> None:
        self._target = value
        self._animation.stop()
        self._animation.setStartValue(self._effect.opacity())
        self._animation.setEndValue(value)
        self._animation.start()

    def _on_finished(self) -> None:
        if self._hide_when_transparent and self._target == 0.0:
            self._widget.hide()


class WidthAnimator(QObject):
    """Animates a widget's maximum width, producing slide-in/out panels."""

    finished = Signal()

    def __init__(self, widget: QWidget, duration_ms: int = SLIDE_DURATION_MS) -> None:
        super().__init__(widget)
        self._widget = widget
        self._animation = QPropertyAnimation(widget, b"maximumWidth", self)
        self._animation.setDuration(duration_ms)
        self._animation.setEasingCurve(QEasingCurve.OutCubic)
        self._animation.finished.connect(self.finished)

    def animate_to(self, width: int) -> None:
        self._animation.stop()
        self._animation.setStartValue(self._widget.maximumWidth())
        self._animation.setEndValue(width)
        self._animation.start()
