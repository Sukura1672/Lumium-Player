"""Entry point: ``python main.py [video files...]``."""

import sys

from lumenplayer.app import run

if __name__ == "__main__":
    sys.exit(run(sys.argv))
