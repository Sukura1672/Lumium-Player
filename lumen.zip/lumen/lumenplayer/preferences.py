"""User preferences persisted through ``QSettings``."""

from __future__ import annotations

from dataclasses import dataclass, fields

from PySide6.QtCore import QSettings

from .constants import DEFAULT_VOLUME, HDR_MODES, MAX_VOLUME


@dataclass
class Preferences:
    """Settings that survive restarts."""

    volume: float = DEFAULT_VOLUME
    hdr_index: int = 0
    subtitles_visible: bool = True
    subtitle_scale: float = 1.0
    subtitle_autoload: bool = True
    resume_playback: bool = True

    @classmethod
    def load(cls, settings: QSettings) -> "Preferences":
        defaults = cls()
        prefs = cls(
            volume=settings.value("volume", defaults.volume, type=float),
            hdr_index=settings.value("hdr_index", defaults.hdr_index, type=int),
            subtitles_visible=settings.value("subtitles_visible", defaults.subtitles_visible, type=bool),
            subtitle_scale=settings.value("subtitle_scale", defaults.subtitle_scale, type=float),
            subtitle_autoload=settings.value("subtitle_autoload", defaults.subtitle_autoload, type=bool),
            resume_playback=settings.value("resume_playback", defaults.resume_playback, type=bool),
        )
        prefs.volume = min(float(MAX_VOLUME), max(0.0, prefs.volume))
        if not 0 <= prefs.hdr_index < len(HDR_MODES):
            prefs.hdr_index = 0
        return prefs

    def save(self, settings: QSettings) -> None:
        for item in fields(self):
            settings.setValue(item.name, getattr(self, item.name))
