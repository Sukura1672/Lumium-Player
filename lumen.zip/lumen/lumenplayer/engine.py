"""Thin, Qt-friendly wrapper around libmpv.

The rest of the application talks to :class:`MpvEngine` only; no other module
imports ``mpv``. mpv invokes its callbacks on its own thread, so every callback
is converted into a Qt signal, which Qt delivers on the GUI thread.
"""

from __future__ import annotations

import locale
import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

from PySide6.QtCore import QObject, Signal

from . import paths
from .constants import (
    EXACT_SEEK_LIMIT_SECONDS,
    HDR_MODES,
    KEYMAP,
    AspectMode,
    HdrMode,
)

# libmpv must be locatable, and numeric parsing must use the C locale, *before* import.
paths.configure_native_library_search()
locale.setlocale(locale.LC_NUMERIC, "C")
import mpv  # noqa: E402  (import order is intentional, see above)

_log = logging.getLogger(__name__)

_MESSAGE_CHANNEL = "lumen"
_MIN_SPEED = 0.25
_MAX_SPEED = 4.0

_VIDEO_OPTIONS: Dict[str, Any] = {
    "vo": "gpu-next",  # libplacebo renderer: Dolby Vision reshaping and tone mapping.
    "gpu_api": "d3d11",
    "gpu_context": "d3d11",
    "hwdec": "auto-safe",
    "video_sync": "audio",
    "tone_mapping": "bt.2390",
    "hdr_compute_peak": "yes",
    "gamut_mapping_mode": "auto",
    "target_trc": "auto",
    "target_prim": "auto",
    "scale": "spline36",
    "dscale": "mitchell",
    "cscale": "bilinear",
    "dither_depth": "auto",
    "deband": "no",
    "vd_lavc_dr": "yes",
}

_CACHE_OPTIONS: Dict[str, Any] = {
    "cache": "yes",
    "demuxer_max_bytes": "150MiB",
    "demuxer_readahead_secs": "20",
}

_SUBTITLE_OPTIONS: Dict[str, Any] = {
    "sub_file_paths": "subs:Subs:Subtitles:subtitles",
    "sub_codepage": "utf8:cp1251",
    "slang": "ru,rus,ru-RU,en,eng",
    "alang": "ru,rus,en,eng",
    "sub_font": "Segoe UI",
    "sub_font_size": 46,
    "sub_border_size": 2.4,
    "sub_shadow_offset": 1,
    "sub_margin_y": 36,
}

# The Qt layer owns the interface; mpv only renders video and an on-screen text.
_INTERFACE_OPTIONS: Dict[str, Any] = {
    "osc": "no",
    "osd_bar": "no",
    "input_default_bindings": "no",
    "input_vo_keyboard": "yes",
    "cursor_autohide": 1500,
    "keep_open": "yes",
    "border": "no",
    "force_window": "yes",
    "idle": "yes",
    "osd_font": "Segoe UI",
    "osd_font_size": 30,
    "osd_border_size": 2,
    "msg_level": "all=warn",
}


@dataclass(frozen=True)
class EngineConfig:
    """Initial playback settings applied when the engine starts."""

    volume: float
    hdr_index: int
    subtitles_visible: bool
    subtitle_scale: float
    subtitle_autoload: bool


@dataclass(frozen=True)
class Track:
    """An audio, video or subtitle stream of the current file."""

    id: int
    kind: str
    language: str
    title: str
    external: bool
    selected: bool

    @classmethod
    def from_mpv(cls, raw: Dict[str, Any]) -> "Track":
        return cls(
            id=int(raw["id"]),
            kind=str(raw.get("type", "")),
            language=str(raw.get("lang", "")),
            title=str(raw.get("title", "")),
            external=bool(raw.get("external", False)),
            selected=bool(raw.get("selected", False)),
        )

    @property
    def label(self) -> str:
        parts = [part for part in (self.language, self.title) if part]
        suffix = " (внешние)" if self.external else ""
        return f"{self.id}: {' · '.join(parts) or 'без названия'}{suffix}"


class MpvEngine(QObject):
    """Owns the mpv instance and exposes playback as methods and signals."""

    position_changed = Signal(float)
    duration_changed = Signal(float)
    paused_changed = Signal(bool)
    title_changed = Signal(str)
    tracks_changed = Signal(object)  # list[Track]
    file_loaded = Signal()
    user_command = Signal(str, object)  # (Action value, Optional[float])

    def __init__(self, window_id: int, config: EngineConfig, parent: Optional[QObject] = None) -> None:
        super().__init__(parent)
        options: Dict[str, Any] = {
            **_VIDEO_OPTIONS,
            **_CACHE_OPTIONS,
            **_SUBTITLE_OPTIONS,
            **_INTERFACE_OPTIONS,
            "wid": str(window_id),
            "target_colorspace_hint": HDR_MODES[config.hdr_index].colorspace_hint,
            "sub_auto": "fuzzy" if config.subtitle_autoload else "no",
            "sub_visibility": "yes" if config.subtitles_visible else "no",
            "sub_scale": config.subtitle_scale,
            "volume": config.volume,
        }
        self._mpv = mpv.MPV(**options)
        self._register_observers()
        self._register_key_bindings()

    # -- State ------------------------------------------------------------

    @property
    def current_path(self) -> Optional[str]:
        return self._mpv.path

    @property
    def media_title(self) -> str:
        return self._mpv.media_title or ""

    @property
    def paused(self) -> bool:
        return bool(self._mpv.pause)

    @property
    def volume(self) -> float:
        return float(self._mpv.volume)

    @property
    def muted(self) -> bool:
        return bool(self._mpv.mute)

    @property
    def subtitle_delay(self) -> float:
        return float(self._mpv.sub_delay)

    @property
    def tracks(self) -> List[Track]:
        return [Track.from_mpv(raw) for raw in (self._mpv.track_list or [])]

    # -- Playback ---------------------------------------------------------

    def load(self, media: Sequence[str]) -> None:
        """Plays the first item and queues the rest."""
        if not media:
            return
        self._mpv.command("loadfile", media[0], "replace")
        for item in media[1:]:
            self._mpv.command("loadfile", item, "append")
        self._mpv.pause = False

    def toggle_pause(self) -> None:
        self._mpv.pause = not self._mpv.pause

    def seek_by(self, delta_seconds: float) -> None:
        mode = "relative+exact" if abs(delta_seconds) < EXACT_SEEK_LIMIT_SECONDS else "relative"
        self._mpv.command("seek", str(delta_seconds), mode)

    def seek_to(self, seconds: float) -> None:
        self._mpv.command("seek", str(seconds), "absolute+exact")

    def step_frame(self, forward: bool) -> None:
        self._mpv.command("frame-step" if forward else "frame-back-step")

    def step_playlist(self, forward: bool) -> None:
        self._mpv.command("playlist-next" if forward else "playlist-prev", "weak")

    def change_speed(self, factor: float) -> float:
        speed = min(_MAX_SPEED, max(_MIN_SPEED, float(self._mpv.speed) * factor))
        self._mpv.speed = speed
        return speed

    def reset_speed(self) -> None:
        self._mpv.speed = 1.0

    # -- Audio ------------------------------------------------------------

    def set_volume(self, volume: float) -> None:
        self._mpv.volume = float(volume)

    def toggle_mute(self) -> bool:
        self._mpv.mute = not self._mpv.mute
        return self.muted

    def select_audio(self, track_id: int) -> None:
        self._mpv.aid = track_id

    def cycle_audio_track(self) -> None:
        self._mpv.command("cycle", "audio")
        self.show_text("Аудио: ${aid} ${audio-codec-name}")

    # -- Video ------------------------------------------------------------

    def set_aspect(self, mode: AspectMode) -> None:
        self._mpv.video_aspect_override = mode.aspect_override
        self._mpv.panscan = mode.panscan
        self._mpv.keepaspect = "yes" if mode.keep_aspect else "no"

    def set_hdr(self, mode: HdrMode) -> None:
        self._mpv.target_colorspace_hint = mode.colorspace_hint

    def toggle_stats(self) -> None:
        self._mpv.command("script-binding", "stats/display-stats-toggle")

    # -- Subtitles --------------------------------------------------------

    def set_subtitles_visible(self, visible: bool) -> None:
        self._mpv.sub_visibility = "yes" if visible else "no"

    def select_subtitle(self, track_id: Optional[int]) -> None:
        self._mpv.sid = track_id if track_id is not None else "no"

    def cycle_subtitle_track(self) -> None:
        self._mpv.command("cycle", "sub")
        self.show_text("Субтитры: ${sid} ${sub-lang}")

    def add_subtitle(self, path: str, select: bool = True) -> None:
        self._mpv.command("sub-add", path, "select" if select else "auto")

    def set_subtitle_scale(self, scale: float) -> None:
        self._mpv.sub_scale = float(scale)

    def set_subtitle_delay(self, seconds: float) -> None:
        self._mpv.sub_delay = round(float(seconds), 2)

    def set_subtitle_autoload(self, enabled: bool) -> None:
        """Controls whether *future* files pick up neighbouring subtitle files."""
        self._mpv.sub_auto = "fuzzy" if enabled else "no"

    # -- Feedback and lifecycle -------------------------------------------

    def show_text(self, text: str) -> None:
        """Shows a transient on-screen message. ``${property}`` is expanded by mpv."""
        self._mpv.show_text(text)

    def shutdown(self) -> None:
        try:
            self._mpv.terminate()
        except Exception:  # noqa: BLE001 - mpv may already be gone during shutdown.
            _log.debug("mpv terminate failed", exc_info=True)

    # -- Wiring -----------------------------------------------------------

    def _register_observers(self) -> None:
        observe = self._mpv.observe_property
        observe("time-pos", lambda _name, value: self.position_changed.emit(float(value or 0.0)))
        observe("duration", lambda _name, value: self.duration_changed.emit(float(value or 0.0)))
        observe("pause", lambda _name, value: self.paused_changed.emit(bool(value)))
        observe("media-title", lambda _name, value: self.title_changed.emit(value or ""))
        observe(
            "track-list",
            lambda _name, value: self.tracks_changed.emit([Track.from_mpv(raw) for raw in value or []]),
        )

        @self._mpv.event_callback("file-loaded")
        def _on_file_loaded(_event: Any) -> None:
            self.file_loaded.emit()

        @self._mpv.message_handler(_MESSAGE_CHANNEL)
        def _on_message(*args: str) -> None:
            if not args:
                return
            argument = float(args[1]) if len(args) > 1 else None
            self.user_command.emit(args[0], argument)

    def _register_key_bindings(self) -> None:
        for key, binding in KEYMAP.items():
            message = f"script-message {_MESSAGE_CHANNEL} {binding.action.value}"
            if binding.arg is not None:
                message += f" {binding.arg}"
            self._mpv.command("keybind", key, message)
