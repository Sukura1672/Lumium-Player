# -*- mode: python ; coding: utf-8 -*-
# PyInstaller build recipe. Build with: pyinstaller --noconfirm --clean LumenPlayer.spec
# Requires mpv-2.dll (libmpv) next to this file.

a = Analysis(
    ["main.py"],
    pathex=[],
    binaries=[("mpv-2.dll", ".")],
    datas=[("icon.png", ".")],
    hiddenimports=[],
    hookspath=[],
    runtime_hooks=[],
    excludes=["tkinter", "unittest", "pydoc"],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="LumenPlayer",
    console=False,
    icon="icon.ico",
    upx=False,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="LumenPlayer",
)
