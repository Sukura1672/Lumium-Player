"""Filesystem locations and native-library discovery."""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

_log = logging.getLogger(__name__)

_DATA_DIR_NAME = "LumenPlayer"


def bundle_dir() -> Path:
    """Returns the directory that holds bundled resources.

    In a PyInstaller build this is the extraction directory; when running from
    source it is the project root (the parent of this package).
    """
    frozen_root = getattr(sys, "_MEIPASS", None)
    if frozen_root:
        return Path(frozen_root)
    return Path(__file__).resolve().parent.parent


def resource_path(name: str) -> Path:
    """Returns the absolute path of a bundled resource file."""
    return bundle_dir() / name


def user_data_dir() -> Path:
    """Returns (and creates) the per-user directory for settings and logs."""
    base = (
        os.environ.get("APPDATA")
        or os.environ.get("XDG_DATA_HOME")
        or str(Path.home() / ".local" / "share")
    )
    path = Path(base) / _DATA_DIR_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def configure_native_library_search() -> None:
    """Makes the bundled ``mpv-2.dll`` discoverable by the dynamic loader."""
    root = str(bundle_dir())
    os.environ["PATH"] = root + os.pathsep + os.environ.get("PATH", "")
    add_dll_directory = getattr(os, "add_dll_directory", None)
    if add_dll_directory is None:
        return
    try:
        add_dll_directory(root)
    except OSError:
        _log.warning("Could not add %s to the DLL search path", root, exc_info=True)
