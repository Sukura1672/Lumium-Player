"""Static configuration: display tables, limits and keyboard bindings."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, NamedTuple, Optional, Tuple

APP_NAME = "Lumen Player"
ORGANIZATION = "LumenPlayer"
SETTINGS_APP = "Lumen"
WINDOWS_APP_ID = "LumenPlayer.Desktop.1"

VIDEO_EXTENSIONS: Tuple[str, ...] = (
    ".mkv", ".mp4", ".avi", ".mov", ".webm", ".m4v", ".ts", ".m2ts",
    ".wmv", ".flv", ".mpg", ".mpeg", ".iso",
)
SUBTITLE_EXTENSIONS: Tuple[str, ...] = (".srt", ".ass", ".ssa", ".sub", ".vtt")

def video_file_filter() -> str:
    """Returns a ``QFileDialog`` filter string for playable video files."""
    patterns = " ".join(f"*{ext}" for ext in VIDEO_EXTENSIONS)
    return f"Видео ({patterns});;Все файлы (*)"


def subtitle_file_filter() -> str:
    """Returns a ``QFileDialog`` filter string for subtitle files."""
    patterns = " ".join(f"*{ext}" for ext in SUBTITLE_EXTENSIONS)
    return f"Субтитры ({patterns});;Все файлы (*)"


SEEK_RESOLUTION = 1000  # Granularity of the seek slider.
MAX_VOLUME = 130
DEFAULT_VOLUME = 80.0
EXACT_SEEK_LIMIT_SECONDS = 10.0  # Short seeks are frame-accurate.

PROGRESS_SAVE_INTERVAL_MS = 5_000
CURSOR_POLL_INTERVAL_MS = 150
CONTROLS_IDLE_TIMEOUT_MS = 2_500

FADE_DURATION_MS = 180
SLIDE_DURATION_MS = 240
PANEL_WIDTH = 340


@dataclass(frozen=True)
class AspectMode:
    """A video stretching preset."""

    label: str
    aspect_override: str  # mpv ``video-aspect-override`` value; "-1" keeps the source.
    panscan: float  # 0.0 letterboxes, 1.0 crops to fill the window.
    keep_aspect: bool


ASPECT_MODES: Tuple[AspectMode, ...] = (
    AspectMode("По размеру окна", "-1", 0.0, True),
    AspectMode("Заполнить экран (обрезать)", "-1", 1.0, True),
    AspectMode("Растянуть на весь экран", "-1", 0.0, False),
    AspectMode("16:9", "16:9", 0.0, True),
    AspectMode("4:3", "4:3", 0.0, True),
    AspectMode("21:9", "21:9", 0.0, True),
    AspectMode("1:1", "1:1", 0.0, True),
)


@dataclass(frozen=True)
class HdrMode:
    """An HDR output policy."""

    label: str
    colorspace_hint: str  # mpv ``target-colorspace-hint`` value.


HDR_MODES: Tuple[HdrMode, ...] = (
    HdrMode("Авто: HDR на HDR-мониторе, тон-маппинг на SDR", "auto"),
    HdrMode("Всегда тон-маппинг в SDR (цвета как задумано)", "no"),
)


class Action(str, Enum):
    """User-facing player commands that keys and mouse buttons can trigger."""

    TOGGLE_PAUSE = "pause"
    TOGGLE_FULLSCREEN = "fullscreen"
    EXIT_FULLSCREEN = "exit_fullscreen"
    SEEK = "seek"
    VOLUME = "volume"
    MUTE = "mute"
    CYCLE_SUBTITLE = "cycle_subtitle"
    TOGGLE_SUBTITLES = "toggle_subtitles"
    CYCLE_AUDIO = "cycle_audio"
    CYCLE_ASPECT = "cycle_aspect"
    CYCLE_HDR = "cycle_hdr"
    OPEN_FILE = "open_file"
    OPEN_SUBTITLE = "open_subtitle"
    SUBTITLE_DELAY = "subtitle_delay"
    SPEED = "speed"
    RESET_SPEED = "reset_speed"
    FRAME_STEP = "frame_step"
    FRAME_BACK = "frame_back"
    NEXT = "next"
    PREVIOUS = "previous"
    STATS = "stats"
    CONTEXT_MENU = "context_menu"
    TOGGLE_PANEL = "panel"


class Binding(NamedTuple):
    """An action plus an optional numeric argument."""

    action: Action
    arg: Optional[float] = None


KEYMAP: Dict[str, Binding] = {
    "SPACE": Binding(Action.TOGGLE_PAUSE),
    "MBTN_LEFT": Binding(Action.TOGGLE_PAUSE),
    "MBTN_LEFT_DBL": Binding(Action.TOGGLE_FULLSCREEN),
    "MBTN_RIGHT": Binding(Action.CONTEXT_MENU),
    "f": Binding(Action.TOGGLE_FULLSCREEN),
    "ENTER": Binding(Action.TOGGLE_FULLSCREEN),
    "ESC": Binding(Action.EXIT_FULLSCREEN),
    "RIGHT": Binding(Action.SEEK, 5),
    "LEFT": Binding(Action.SEEK, -5),
    "shift+RIGHT": Binding(Action.SEEK, 30),
    "shift+LEFT": Binding(Action.SEEK, -30),
    "ctrl+RIGHT": Binding(Action.SEEK, 120),
    "ctrl+LEFT": Binding(Action.SEEK, -120),
    "UP": Binding(Action.VOLUME, 5),
    "DOWN": Binding(Action.VOLUME, -5),
    "WHEEL_UP": Binding(Action.VOLUME, 5),
    "WHEEL_DOWN": Binding(Action.VOLUME, -5),
    "m": Binding(Action.MUTE),
    "v": Binding(Action.CYCLE_SUBTITLE),
    "c": Binding(Action.TOGGLE_SUBTITLES),
    "b": Binding(Action.CYCLE_AUDIO),
    "a": Binding(Action.CYCLE_ASPECT),
    "h": Binding(Action.CYCLE_HDR),
    "o": Binding(Action.OPEN_FILE),
    "s": Binding(Action.OPEN_SUBTITLE),
    "z": Binding(Action.SUBTITLE_DELAY, -0.1),
    "x": Binding(Action.SUBTITLE_DELAY, 0.1),
    "[": Binding(Action.SPEED, 0.9),
    "]": Binding(Action.SPEED, 1.1),
    "BS": Binding(Action.RESET_SPEED),
    ".": Binding(Action.FRAME_STEP),
    ",": Binding(Action.FRAME_BACK),
    "n": Binding(Action.NEXT),
    "p": Binding(Action.PREVIOUS),
    "i": Binding(Action.STATS),
    "TAB": Binding(Action.TOGGLE_PANEL),
}
