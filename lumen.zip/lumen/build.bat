@echo off
REM Builds Lumen Player: runs tests, packages the exe (PyInstaller) and the installer (Inno Setup).
REM Requires: Python 3.10+, Inno Setup 6 (iscc in PATH), and mpv-2.dll (libmpv) next to this file.
setlocal
cd /d "%~dp0"

if not exist mpv-2.dll (
    echo.
    echo mpv-2.dll not found.
    echo Download "mpv-dev-x86_64-*.7z" from https://github.com/shinchiro/mpv-winbuild-cmake/releases
    echo extract libmpv-2.dll, rename it to mpv-2.dll and put it next to build.bat.
    goto :fail
)

if not exist .venv (
    python -m venv .venv || goto :fail
)
call .venv\Scripts\activate.bat
pip install -r requirements.txt || goto :fail

python -m unittest discover -s tests -t . || goto :fail
pyinstaller --noconfirm --clean LumenPlayer.spec || goto :fail
iscc installer.iss || goto :fail

echo.
echo Done: Output\LumenPlayer-Setup.exe
exit /b 0

:fail
echo Build failed.
exit /b 1
