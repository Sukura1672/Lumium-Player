"""Persistent watch history and user collections.

This module is deliberately free of Qt and mpv imports so it can be unit
tested in isolation.
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

_log = logging.getLogger(__name__)

_SCHEMA_VERSION = 1
MAX_HISTORY_ENTRIES = 300
RESUME_MIN_SECONDS = 5.0
RESUME_END_FRACTION = 0.95


def format_duration(seconds: Optional[float]) -> str:
    """Formats seconds as ``M:SS`` or ``H:MM:SS``."""
    total = max(0, int(seconds or 0))
    hours, remainder = divmod(total, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def normalize_path(path: str) -> str:
    """Returns a stable dictionary key for a local path or a URL."""
    if "://" in path:
        return path
    return os.path.normcase(os.path.abspath(path))


@dataclass
class HistoryEntry:
    """Playback state remembered for one media file."""

    path: str
    title: str
    position: float = 0.0
    duration: float = 0.0
    last_played: float = field(default_factory=time.time)
    subtitles: List[str] = field(default_factory=list)

    @property
    def progress(self) -> float:
        """Fraction of the media that was watched, in ``[0, 1]``."""
        if self.duration <= 0:
            return 0.0
        return min(1.0, max(0.0, self.position / self.duration))

    @property
    def is_resumable(self) -> bool:
        """Whether playback should continue from ``position`` next time."""
        return (
            self.duration > 0
            and self.position >= RESUME_MIN_SECONDS
            and self.position < self.duration * RESUME_END_FRACTION
        )

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "HistoryEntry":
        return cls(
            path=str(raw["path"]),
            title=str(raw.get("title") or os.path.basename(str(raw["path"]))),
            position=float(raw.get("position", 0.0)),
            duration=float(raw.get("duration", 0.0)),
            last_played=float(raw.get("last_played", 0.0)),
            subtitles=[str(item) for item in raw.get("subtitles", [])],
        )


class Library:
    """Stores watch history and named collections in a JSON file."""

    def __init__(self, file_path: Path) -> None:
        self._file_path = file_path
        self._history: Dict[str, HistoryEntry] = {}
        self._collections: Dict[str, List[str]] = {}
        self._load()

    # -- History ----------------------------------------------------------

    def history_entry(self, path: str) -> Optional[HistoryEntry]:
        return self._history.get(normalize_path(path))

    def recent(self, limit: Optional[int] = None) -> List[HistoryEntry]:
        """Returns history entries, most recently played first."""
        entries = sorted(self._history.values(), key=lambda e: e.last_played, reverse=True)
        return entries[:limit] if limit is not None else entries

    def record_playback(
        self, path: str, *, title: str, position: float, duration: float
    ) -> HistoryEntry:
        """Creates or updates the entry for ``path`` and marks it as just played."""
        key = normalize_path(path)
        entry = self._history.get(key)
        if entry is None:
            entry = HistoryEntry(path=path, title=title)
            self._history[key] = entry
        entry.title = title or entry.title
        entry.position = max(0.0, position)
        if duration > 0:  # Keep the known duration while the demuxer is still probing.
            entry.duration = duration
        entry.last_played = time.time()
        self._trim_history()
        return entry

    def attach_subtitle(self, path: str, subtitle: str) -> None:
        """Remembers a user-supplied subtitle file for ``path``."""
        key = normalize_path(path)
        entry = self._history.get(key)
        if entry is None:
            entry = HistoryEntry(path=path, title=os.path.basename(path))
            self._history[key] = entry
        if subtitle not in entry.subtitles:
            entry.subtitles.append(subtitle)

    def remove_history(self, path: str) -> None:
        self._history.pop(normalize_path(path), None)

    def clear_history(self) -> None:
        self._history.clear()

    def _trim_history(self) -> None:
        overflow = len(self._history) - MAX_HISTORY_ENTRIES
        if overflow <= 0:
            return
        oldest = sorted(self._history.items(), key=lambda kv: kv[1].last_played)[:overflow]
        for key, _entry in oldest:
            del self._history[key]

    # -- Collections ------------------------------------------------------

    def collection_names(self) -> List[str]:
        return sorted(self._collections, key=str.casefold)

    def create_collection(self, name: str) -> bool:
        """Creates an empty collection. Returns False for blank or duplicate names."""
        name = name.strip()
        if not name or name in self._collections:
            return False
        self._collections[name] = []
        return True

    def delete_collection(self, name: str) -> None:
        self._collections.pop(name, None)

    def collection_items(self, name: str) -> List[str]:
        return list(self._collections.get(name, []))

    def add_to_collection(self, name: str, paths: Iterable[str]) -> int:
        """Appends ``paths`` that are not yet present. Returns the number added."""
        items = self._collections.get(name)
        if items is None:
            return 0
        known = {normalize_path(item) for item in items}
        added = 0
        for path in paths:
            key = normalize_path(path)
            if key not in known:
                items.append(path)
                known.add(key)
                added += 1
        return added

    def remove_from_collection(self, name: str, index: int) -> None:
        items = self._collections.get(name)
        if items is not None and 0 <= index < len(items):
            del items[index]

    # -- Persistence ------------------------------------------------------

    def save(self) -> None:
        """Writes the library atomically so a crash cannot corrupt it."""
        payload = {
            "version": _SCHEMA_VERSION,
            "history": [asdict(entry) for entry in self._history.values()],
            "collections": self._collections,
        }
        tmp_path = self._file_path.with_suffix(".tmp")
        try:
            tmp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(tmp_path, self._file_path)
        except OSError:
            _log.exception("Failed to save library to %s", self._file_path)

    def _load(self) -> None:
        if not self._file_path.exists():
            return
        try:
            raw = json.loads(self._file_path.read_text(encoding="utf-8"))
            for item in raw.get("history", []):
                entry = HistoryEntry.from_dict(item)
                self._history[normalize_path(entry.path)] = entry
            for name, items in raw.get("collections", {}).items():
                self._collections[str(name)] = [str(item) for item in items]
        except (OSError, ValueError, KeyError, TypeError, AttributeError):
            _log.exception("Library file is unreadable; starting empty")
            self._history.clear()
            self._collections.clear()
            self._quarantine_corrupt_file()

    def _quarantine_corrupt_file(self) -> None:
        backup = self._file_path.with_suffix(".corrupt")
        try:
            os.replace(self._file_path, backup)
        except OSError:
            _log.warning("Could not move the corrupt library aside", exc_info=True)
