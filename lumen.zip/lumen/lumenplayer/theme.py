"""Dark theme: palette and stylesheet."""

from __future__ import annotations

from string import Template

from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import QApplication


class Colors:
    """Design tokens shared by the stylesheet and the icon renderer."""

    BACKGROUND = "#0f0f10"
    SURFACE = "#17171a"
    SURFACE_RAISED = "#1e1e22"
    BORDER = "#2b2b31"
    HOVER = "#26262c"
    ACCENT = "#7c9cff"
    ACCENT_SOFT = "#2a2f45"
    TEXT = "#e8e8ea"
    TEXT_MUTED = "#9a9aa2"
    ICON = "#d6d6da"
    ICON_ACTIVE = "#ffffff"
    ICON_DISABLED = "#5c5c63"


_STYLESHEET = Template(
    """
* { font-family: 'Segoe UI', sans-serif; font-size: 13px; }
QMainWindow, QWidget#controlBar { background: $BACKGROUND; }
QWidget#sidePanel, QWidget#panelInner { background: $SURFACE; }
QLabel { color: $TEXT_MUTED; }
QLabel#section { color: $TEXT; font-weight: 600; padding-top: 4px; }
QCheckBox { color: $TEXT; spacing: 8px; }

QToolButton { background: transparent; border: none; border-radius: 8px; padding: 6px; }
QToolButton:hover { background: $HOVER; }
QToolButton:checked { background: $ACCENT_SOFT; }
QToolButton#tab { color: $TEXT_MUTED; padding: 6px 8px; }
QToolButton#tab:checked { color: $TEXT; }

QPushButton { background: $SURFACE_RAISED; color: $TEXT; border: 1px solid $BORDER;
              border-radius: 8px; padding: 7px 12px; }
QPushButton:hover { background: $HOVER; }
QPushButton#primary { background: $ACCENT; color: #0b0d16; border: none; font-weight: 600; }
QPushButton#primary:hover { background: #93adff; }

QSlider::groove:horizontal { height: 4px; background: $BORDER; border-radius: 2px; }
QSlider::sub-page:horizontal { background: $ACCENT; border-radius: 2px; }
QSlider::handle:horizontal { width: 12px; height: 12px; margin: -4px 0; border-radius: 6px;
                             background: $TEXT; }

QComboBox, QDoubleSpinBox { background: $SURFACE_RAISED; color: $TEXT; border: 1px solid $BORDER;
                            border-radius: 8px; padding: 5px 8px; }
QComboBox QAbstractItemView { background: $SURFACE_RAISED; color: $TEXT; border: 1px solid $BORDER;
                              selection-background-color: $ACCENT_SOFT; }

QListWidget { background: $BACKGROUND; border: 1px solid $BORDER; border-radius: 10px;
              color: $TEXT; outline: none; padding: 4px; }
QListWidget::item { padding: 8px; border-radius: 6px; }
QListWidget::item:hover { background: $HOVER; }
QListWidget::item:selected { background: $ACCENT_SOFT; color: $TEXT; }

QMenu { background: $SURFACE; color: $TEXT; border: 1px solid $BORDER; padding: 4px; }
QMenu::item { padding: 6px 24px; border-radius: 4px; }
QMenu::item:selected { background: $HOVER; }
QMenu::separator { height: 1px; background: $BORDER; margin: 4px 8px; }
QToolTip { background: $SURFACE_RAISED; color: $TEXT; border: 1px solid $BORDER; }
"""
).substitute({k: v for k, v in vars(Colors).items() if k.isupper()})


def apply_dark_theme(app: QApplication) -> None:
    """Applies the Fusion style, a dark palette and the application stylesheet."""
    app.setStyle("Fusion")
    palette = QPalette()
    palette.setColor(QPalette.Window, QColor(Colors.BACKGROUND))
    palette.setColor(QPalette.WindowText, QColor(Colors.TEXT))
    palette.setColor(QPalette.Base, QColor(Colors.SURFACE))
    palette.setColor(QPalette.Text, QColor(Colors.TEXT))
    palette.setColor(QPalette.Button, QColor(Colors.SURFACE_RAISED))
    palette.setColor(QPalette.ButtonText, QColor(Colors.TEXT))
    palette.setColor(QPalette.Highlight, QColor(Colors.ACCENT))
    palette.setColor(QPalette.HighlightedText, QColor("#0b0d16"))
    app.setPalette(palette)
    app.setStyleSheet(_STYLESHEET)
