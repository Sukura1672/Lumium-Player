"""The sliding side panel: settings, watch history and collections."""

from __future__ import annotations

import os
import time
from contextlib import contextmanager
from dataclasses import dataclass
from enum import IntEnum
from typing import Callable, Iterator, List, Optional, Sequence

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QSlider,
    QStackedWidget,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from .animations import OpacityFader, WidthAnimator
from .constants import ASPECT_MODES, HDR_MODES, PANEL_WIDTH, video_file_filter
from .engine import Track
from .icons import icon
from .library import HistoryEntry, Library, format_duration
from .theme import Colors

_MIN_SUBTITLE_SCALE_PERCENT = 50
_MAX_SUBTITLE_SCALE_PERCENT = 200
_SUBTITLE_DELAY_RANGE_SECONDS = 120.0


@contextmanager
def _signals_blocked(*widgets: QWidget) -> Iterator[None]:
    """Temporarily silences widget signals while state is synchronised."""
    previous = [widget.blockSignals(True) for widget in widgets]
    try:
        yield
    finally:
        for widget, was_blocked in zip(widgets, previous):
            widget.blockSignals(was_blocked)


def _section_label(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName("section")
    return label


@dataclass(frozen=True)
class PanelState:
    """Initial values shown by the settings page."""

    subtitles_visible: bool
    subtitle_scale: float
    subtitle_autoload: bool
    resume_playback: bool
    aspect_index: int
    hdr_index: int


class SettingsPage(QWidget):
    """Subtitle, picture and playback options."""

    subtitles_visibility_changed = Signal(bool)
    subtitle_track_selected = Signal(object)  # Optional[int]; None disables subtitles.
    add_subtitles_requested = Signal()
    subtitle_scale_changed = Signal(float)
    subtitle_delay_changed = Signal(float)
    subtitle_autoload_changed = Signal(bool)
    aspect_mode_selected = Signal(int)
    hdr_mode_selected = Signal(int)
    resume_changed = Signal(bool)

    def __init__(self, state: PanelState) -> None:
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)

        layout.addWidget(_section_label("Субтитры"))
        self._show_subtitles = QCheckBox("Показывать субтитры")
        self._show_subtitles.setChecked(state.subtitles_visible)
        self._show_subtitles.toggled.connect(self.subtitles_visibility_changed)
        layout.addWidget(self._show_subtitles)

        self._track_box = QComboBox()
        self._track_box.activated.connect(self._on_track_activated)
        layout.addWidget(self._track_box)

        add_button = QPushButton(" Добавить свои субтитры…")
        add_button.setIcon(icon("plus", 16))
        add_button.clicked.connect(self.add_subtitles_requested)
        layout.addWidget(add_button)

        self._scale_label = QLabel()
        self._scale_slider = QSlider(Qt.Horizontal)
        self._scale_slider.setRange(_MIN_SUBTITLE_SCALE_PERCENT, _MAX_SUBTITLE_SCALE_PERCENT)
        self._scale_slider.setValue(round(state.subtitle_scale * 100))
        self._scale_slider.valueChanged.connect(self._on_scale_changed)
        self._update_scale_label(self._scale_slider.value())
        scale_row = QHBoxLayout()
        scale_row.addWidget(QLabel("Размер"))
        scale_row.addWidget(self._scale_slider, 1)
        scale_row.addWidget(self._scale_label)
        layout.addLayout(scale_row)

        self._delay_box = QDoubleSpinBox()
        self._delay_box.setRange(-_SUBTITLE_DELAY_RANGE_SECONDS, _SUBTITLE_DELAY_RANGE_SECONDS)
        self._delay_box.setSingleStep(0.1)
        self._delay_box.setDecimals(1)
        self._delay_box.setSuffix(" с")
        self._delay_box.valueChanged.connect(self.subtitle_delay_changed)
        delay_row = QHBoxLayout()
        delay_row.addWidget(QLabel("Задержка"))
        delay_row.addWidget(self._delay_box, 1)
        layout.addLayout(delay_row)

        self._autoload = QCheckBox("Подгружать субтитры рядом с видео")
        self._autoload.setChecked(state.subtitle_autoload)
        self._autoload.toggled.connect(self.subtitle_autoload_changed)
        layout.addWidget(self._autoload)

        layout.addWidget(_section_label("Изображение"))
        self._aspect_box = QComboBox()
        self._aspect_box.addItems([mode.label for mode in ASPECT_MODES])
        self._aspect_box.setCurrentIndex(state.aspect_index)
        self._aspect_box.activated.connect(self.aspect_mode_selected)
        layout.addWidget(self._aspect_box)

        self._hdr_box = QComboBox()
        self._hdr_box.addItems([mode.label for mode in HDR_MODES])
        self._hdr_box.setCurrentIndex(state.hdr_index)
        self._hdr_box.activated.connect(self.hdr_mode_selected)
        layout.addWidget(self._hdr_box)

        layout.addWidget(_section_label("Воспроизведение"))
        self._resume = QCheckBox("Продолжать с места остановки")
        self._resume.setChecked(state.resume_playback)
        self._resume.toggled.connect(self.resume_changed)
        layout.addWidget(self._resume)
        layout.addStretch(1)

    # -- Synchronisation with the player ----------------------------------

    def set_subtitles_visible(self, visible: bool) -> None:
        with _signals_blocked(self._show_subtitles):
            self._show_subtitles.setChecked(visible)

    def set_aspect_index(self, index: int) -> None:
        with _signals_blocked(self._aspect_box):
            self._aspect_box.setCurrentIndex(index)

    def set_hdr_index(self, index: int) -> None:
        with _signals_blocked(self._hdr_box):
            self._hdr_box.setCurrentIndex(index)

    def set_subtitle_delay(self, seconds: float) -> None:
        with _signals_blocked(self._delay_box):
            self._delay_box.setValue(seconds)

    def set_tracks(self, tracks: Sequence[Track]) -> None:
        """Repopulates the subtitle track list from the current file."""
        subtitle_tracks = [track for track in tracks if track.kind == "sub"]
        with _signals_blocked(self._track_box):
            self._track_box.clear()
            self._track_box.addItem("Субтитры выключены", None)
            selected_row = 0
            for row, track in enumerate(subtitle_tracks, start=1):
                self._track_box.addItem(track.label, track.id)
                if track.selected:
                    selected_row = row
            self._track_box.setCurrentIndex(selected_row)

    # -- Slots --------------------------------------------------------------

    def _on_track_activated(self, row: int) -> None:
        self.subtitle_track_selected.emit(self._track_box.itemData(row))

    def _on_scale_changed(self, percent: int) -> None:
        self._update_scale_label(percent)
        self.subtitle_scale_changed.emit(percent / 100.0)

    def _update_scale_label(self, percent: int) -> None:
        self._scale_label.setText(f"{percent}%")


class HistoryPage(QWidget):
    """Recently watched files; double-click to continue watching."""

    play_requested = Signal(str)

    def __init__(self, library: Library) -> None:
        super().__init__()
        self._library = library
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)

        self._list = QListWidget()
        self._list.itemActivated.connect(self._on_item_activated)
        layout.addWidget(self._list, 1)

        buttons = QHBoxLayout()
        remove_button = QPushButton(" Убрать")
        remove_button.setIcon(icon("trash", 16))
        remove_button.clicked.connect(self._remove_selected)
        clear_button = QPushButton("Очистить всё")
        clear_button.clicked.connect(self._clear_all)
        buttons.addWidget(remove_button)
        buttons.addWidget(clear_button)
        layout.addLayout(buttons)

    def refresh(self) -> None:
        self._list.clear()
        for entry in self._library.recent():
            item = QListWidgetItem(self._describe(entry))
            item.setData(Qt.UserRole, entry.path)
            item.setToolTip(entry.path)
            if "://" not in entry.path and not os.path.exists(entry.path):
                item.setForeground(QBrush(QColor(Colors.TEXT_MUTED)))
            self._list.addItem(item)

    @staticmethod
    def _describe(entry: HistoryEntry) -> str:
        watched = f"{format_duration(entry.position)} / {format_duration(entry.duration)}"
        when = time.strftime("%d.%m %H:%M", time.localtime(entry.last_played))
        return f"{entry.title}\n{watched} · {when}"

    def _on_item_activated(self, item: QListWidgetItem) -> None:
        self.play_requested.emit(item.data(Qt.UserRole))

    def _remove_selected(self) -> None:
        item = self._list.currentItem()
        if item is None:
            return
        self._library.remove_history(item.data(Qt.UserRole))
        self._library.save()
        self.refresh()

    def _clear_all(self) -> None:
        answer = QMessageBox.question(self, "История", "Удалить всю историю просмотра?")
        if answer != QMessageBox.Yes:
            return
        self._library.clear_history()
        self._library.save()
        self.refresh()


class CollectionsPage(QWidget):
    """Named lists of files the user wants to keep together."""

    play_requested = Signal(list)  # list[str]

    def __init__(self, library: Library, current_path: Callable[[], Optional[str]]) -> None:
        super().__init__()
        self._library = library
        self._current_path = current_path

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)

        header = QHBoxLayout()
        self._collection_box = QComboBox()
        self._collection_box.currentIndexChanged.connect(self._refresh_items)
        header.addWidget(self._collection_box, 1)
        header.addWidget(self._tool_button("plus", "Новая коллекция", self._create_collection))
        header.addWidget(self._tool_button("trash", "Удалить коллекцию", self._delete_collection))
        layout.addLayout(header)

        self._items = QListWidget()
        self._items.itemActivated.connect(lambda _item: self._play_from(self._items.currentRow()))
        layout.addWidget(self._items, 1)

        play_button = QPushButton(" Играть")
        play_button.setObjectName("primary")
        play_button.setIcon(icon("play", 16))
        play_button.clicked.connect(lambda: self._play_from(max(0, self._items.currentRow())))
        layout.addWidget(play_button)

        row = QHBoxLayout()
        add_current = QPushButton("＋ Текущий")
        add_current.clicked.connect(self._add_current)
        add_files = QPushButton("＋ Файлы…")
        add_files.clicked.connect(self._add_files)
        remove = QPushButton("Убрать")
        remove.clicked.connect(self._remove_selected)
        for button in (add_current, add_files, remove):
            row.addWidget(button)
        layout.addLayout(row)

    @staticmethod
    def _tool_button(icon_name: str, tooltip: str, slot: Callable[[], None]) -> QToolButton:
        button = QToolButton()
        button.setIcon(icon(icon_name, 18))
        button.setIconSize(QSize(18, 18))
        button.setToolTip(tooltip)
        button.clicked.connect(slot)
        return button

    def refresh(self) -> None:
        """Reloads the collection list, keeping the current selection if possible."""
        selected = self._collection_box.currentText()
        with _signals_blocked(self._collection_box):
            self._collection_box.clear()
            self._collection_box.addItems(self._library.collection_names())
            index = self._collection_box.findText(selected)
            self._collection_box.setCurrentIndex(max(0, index))
        self._refresh_items()

    @property
    def _name(self) -> Optional[str]:
        return self._collection_box.currentText() or None

    def _refresh_items(self) -> None:
        self._items.clear()
        name = self._name
        if name is None:
            return
        for path in self._library.collection_items(name):
            item = QListWidgetItem(os.path.basename(path) or path)
            item.setToolTip(path)
            self._items.addItem(item)

    def _create_collection(self) -> None:
        name, accepted = QInputDialog.getText(self, "Новая коллекция", "Название:")
        if not accepted:
            return
        if not self._library.create_collection(name):
            QMessageBox.information(self, "Коллекции", "Введите уникальное непустое название.")
            return
        self._library.save()
        self.refresh()
        self._collection_box.setCurrentIndex(self._collection_box.findText(name.strip()))

    def _delete_collection(self) -> None:
        name = self._name
        if name is None:
            return
        answer = QMessageBox.question(self, "Коллекции", f"Удалить коллекцию «{name}»?")
        if answer != QMessageBox.Yes:
            return
        self._library.delete_collection(name)
        self._library.save()
        self.refresh()

    def _ensure_collection(self) -> Optional[str]:
        """Returns the selected collection, offering to create one if none exist."""
        if self._name is None:
            self._create_collection()
        return self._name

    def _add_current(self) -> None:
        path = self._current_path()
        name = self._ensure_collection()
        if path is None or name is None:
            return
        self._library.add_to_collection(name, [path])
        self._library.save()
        self._refresh_items()

    def _add_files(self) -> None:
        name = self._ensure_collection()
        if name is None:
            return
        files, _ = QFileDialog.getOpenFileNames(self, "Добавить в коллекцию", "", video_file_filter())
        if not files:
            return
        self._library.add_to_collection(name, files)
        self._library.save()
        self._refresh_items()

    def _remove_selected(self) -> None:
        name = self._name
        row = self._items.currentRow()
        if name is None or row < 0:
            return
        self._library.remove_from_collection(name, row)
        self._library.save()
        self._refresh_items()

    def _play_from(self, row: int) -> None:
        name = self._name
        if name is None:
            return
        items: List[str] = self._library.collection_items(name)
        if 0 <= row < len(items):
            self.play_requested.emit(items[row:])


class SidePanel(QWidget):
    """Container that slides in from the right and hosts the three pages."""

    class Tab(IntEnum):
        SETTINGS = 0
        HISTORY = 1
        COLLECTIONS = 2

    visibility_changed = Signal(bool)

    _TABS = (
        (Tab.SETTINGS, "Настройки", "sliders"),
        (Tab.HISTORY, "История", "clock"),
        (Tab.COLLECTIONS, "Коллекции", "list"),
    )

    def __init__(
        self,
        library: Library,
        state: PanelState,
        current_path: Callable[[], Optional[str]],
    ) -> None:
        super().__init__()
        self.setObjectName("sidePanel")
        self.setMinimumWidth(0)
        self.setMaximumWidth(0)
        self.hide()
        self._open = False

        self.settings_page = SettingsPage(state)
        self.history_page = HistoryPage(library)
        self.collections_page = CollectionsPage(library, current_path)

        # The content has a fixed width and is clipped by the animated container,
        # so it does not reflow while the panel slides.
        self._inner = QWidget(self)
        self._inner.setObjectName("panelInner")
        self._inner.setFixedWidth(PANEL_WIDTH)
        layout = QVBoxLayout(self._inner)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(12)

        self._stack = QStackedWidget()
        tab_row = QHBoxLayout()
        tab_row.setSpacing(2)
        self._tab_group = QButtonGroup(self)
        for tab, title, icon_name in self._TABS:
            button = QToolButton()
            button.setObjectName("tab")
            button.setText(title)
            button.setIcon(icon(icon_name, 18))
            button.setIconSize(QSize(18, 18))
            button.setCheckable(True)
            button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            self._tab_group.addButton(button, int(tab))
            tab_row.addWidget(button)
        self._stack.addWidget(self.settings_page)
        self._stack.addWidget(self.history_page)
        self._stack.addWidget(self.collections_page)
        self._tab_group.button(int(self.Tab.SETTINGS)).setChecked(True)
        self._tab_group.idClicked.connect(self._on_tab_clicked)
        layout.addLayout(tab_row)
        layout.addWidget(self._stack, 1)

        self._page_fader = OpacityFader(self._stack)
        self._slider = WidthAnimator(self)
        self._slider.finished.connect(self._on_slide_finished)

    @property
    def is_open(self) -> bool:
        return self._open

    @property
    def current_tab(self) -> "SidePanel.Tab":
        return self.Tab(self._stack.currentIndex())

    def toggle(self, tab: Optional["SidePanel.Tab"] = None) -> None:
        """Opens the panel, or closes it if the requested tab is already shown."""
        if self._open and (tab is None or tab == self.current_tab):
            self.collapse()
        else:
            self.expand(tab)

    def expand(self, tab: Optional["SidePanel.Tab"] = None) -> None:
        if tab is not None:
            self._show_tab(tab)
        else:
            self._refresh_page(self.current_tab)
        if self._open:
            return
        self._open = True
        self.show()
        self._slider.animate_to(PANEL_WIDTH)
        self.visibility_changed.emit(True)

    def collapse(self) -> None:
        if not self._open:
            return
        self._open = False
        self._slider.animate_to(0)
        self.visibility_changed.emit(False)

    def refresh_history(self) -> None:
        """Updates the history list when it is on screen."""
        if self._open and self.current_tab == self.Tab.HISTORY:
            self.history_page.refresh()

    def resizeEvent(self, event) -> None:  # noqa: N802 (Qt override)
        super().resizeEvent(event)
        self._inner.setGeometry(0, 0, PANEL_WIDTH, self.height())

    def _on_tab_clicked(self, tab_id: int) -> None:
        self._show_tab(self.Tab(tab_id))

    def _show_tab(self, tab: "SidePanel.Tab") -> None:
        self._tab_group.button(int(tab)).setChecked(True)
        if self._stack.currentIndex() != int(tab):
            self._stack.setCurrentIndex(int(tab))
            self._page_fader.flash_in(0.2)
        self._refresh_page(tab)

    def _refresh_page(self, tab: "SidePanel.Tab") -> None:
        if tab == self.Tab.HISTORY:
            self.history_page.refresh()
        elif tab == self.Tab.COLLECTIONS:
            self.collections_page.refresh()

    def _on_slide_finished(self) -> None:
        if not self._open:
            self.hide()
