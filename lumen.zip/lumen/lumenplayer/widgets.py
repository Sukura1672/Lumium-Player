"""Small custom widgets."""

from __future__ import annotations

from PySide6.QtCore import QObject, QPoint, QTimer, Qt, Signal
from PySide6.QtGui import QCursor, QMouseEvent
from PySide6.QtWidgets import QSlider, QStyle, QWidget

from .constants import CURSOR_POLL_INTERVAL_MS


class VideoSurface(QWidget):
    """A native window handle that libmpv renders into."""

    def __init__(self) -> None:
        super().__init__()
        self.setAttribute(Qt.WA_NativeWindow, True)
        self.setAttribute(Qt.WA_DontCreateNativeAncestors, True)
        self.setStyleSheet("background: #000;")


class SeekSlider(QSlider):
    """A horizontal slider that jumps to the clicked position."""

    def __init__(self) -> None:
        super().__init__(Qt.Horizontal)

    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802 (Qt override)
        if event.button() == Qt.LeftButton:
            value = QStyle.sliderValueFromPosition(
                self.minimum(), self.maximum(), int(event.position().x()), self.width()
            )
            self.setValue(value)
            self.sliderMoved.emit(value)
        super().mousePressEvent(event)


class CursorActivityWatcher(QObject):
    """Polls the global cursor position and reports movement and idleness.

    The video surface is a native child window that swallows mouse events, so
    polling is the reliable way to know whether the user is active.
    """

    moved = Signal()
    idle = Signal()

    def __init__(self, idle_timeout_ms: int, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._idle_timeout_ms = idle_timeout_ms
        self._last_position = QPoint()
        self._idle_ms = 0
        self._idle_reported = False
        self._timer = QTimer(self)
        self._timer.setInterval(CURSOR_POLL_INTERVAL_MS)
        self._timer.timeout.connect(self._poll)

    def start(self) -> None:
        self._timer.start()

    def stop(self) -> None:
        self._timer.stop()

    def _poll(self) -> None:
        position = QCursor.pos()
        if position != self._last_position:
            self._last_position = position
            self._idle_ms = 0
            self._idle_reported = False
            self.moved.emit()
            return
        self._idle_ms += CURSOR_POLL_INTERVAL_MS
        if self._idle_ms >= self._idle_timeout_ms and not self._idle_reported:
            self._idle_reported = True
            self.idle.emit()
