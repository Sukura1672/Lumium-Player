"""The main player window: wires the engine, the controls and the side panel."""

from __future__ import annotations

import logging
import os
from typing import Callable, Dict, List, Optional, Sequence

from PySide6.QtCore import QSettings, QSize, QTimer, Qt
from PySide6.QtGui import QActionGroup, QCursor, QDragEnterEvent, QDropEvent
from PySide6.QtWidgets import (
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMenu,
    QSlider,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from .animations import OpacityFader
from .constants import (
    APP_NAME,
    ASPECT_MODES,
    CONTROLS_IDLE_TIMEOUT_MS,
    HDR_MODES,
    MAX_VOLUME,
    ORGANIZATION,
    PROGRESS_SAVE_INTERVAL_MS,
    SEEK_RESOLUTION,
    SETTINGS_APP,
    SUBTITLE_EXTENSIONS,
    Action,
    subtitle_file_filter,
    video_file_filter,
)
from .engine import EngineConfig, MpvEngine, Track
from .icons import icon
from .library import Library, format_duration
from .panel import PanelState, SidePanel
from .paths import user_data_dir
from .preferences import Preferences
from .widgets import CursorActivityWatcher, SeekSlider, VideoSurface

_log = logging.getLogger(__name__)

_ICON_SIZE = QSize(22, 22)


class PlayerWindow(QMainWindow):
    """Top-level window of the application."""

    def __init__(self, files: Sequence[str]) -> None:
        super().__init__()
        self._qsettings = QSettings(ORGANIZATION, SETTINGS_APP)
        self._prefs = Preferences.load(self._qsettings)
        self._library = Library(user_data_dir() / "library.json")

        self._aspect_index = 0
        self._duration = 0.0
        self._last_position = 0.0
        self._scrubbing = False
        self._current_path: Optional[str] = None
        self._media_title = ""

        self.setWindowTitle(APP_NAME)
        self.setAcceptDrops(True)
        self.resize(1180, 700)
        self.setMinimumSize(520, 320)

        self._build_ui()
        self._engine = self._create_engine()
        self._connect_engine()
        self._handlers = self._build_action_table()
        self._start_background_services()

        if files:
            self.open_files(files)

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        self._video = VideoSurface()
        self._panel = SidePanel(
            self._library,
            PanelState(
                subtitles_visible=self._prefs.subtitles_visible,
                subtitle_scale=self._prefs.subtitle_scale,
                subtitle_autoload=self._prefs.subtitle_autoload,
                resume_playback=self._prefs.resume_playback,
                aspect_index=self._aspect_index,
                hdr_index=self._prefs.hdr_index,
            ),
            current_path=lambda: self._current_path,
        )
        self._controls = self._build_controls()
        self._controls_fader = OpacityFader(self._controls, hide_when_transparent=True)

        stage = QHBoxLayout()
        stage.setContentsMargins(0, 0, 0, 0)
        stage.setSpacing(0)
        stage.addWidget(self._video, 1)
        stage.addWidget(self._panel)

        root = QWidget()
        column = QVBoxLayout(root)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        column.addLayout(stage, 1)
        column.addWidget(self._controls)
        self.setCentralWidget(root)

        self._connect_panel()

    def _build_controls(self) -> QWidget:
        bar = QWidget()
        bar.setObjectName("controlBar")
        row = QHBoxLayout(bar)
        row.setContentsMargins(10, 6, 10, 8)
        row.setSpacing(2)

        self._open_button = self._tool_button("folder", "Открыть файл (O)", self._prompt_open_files)
        self._previous_button = self._tool_button("previous", "Предыдущий (P)", lambda: self._engine.step_playlist(False))
        self._play_button = self._tool_button("play", "Пауза (Пробел)", lambda: self._engine.toggle_pause())
        self._next_button = self._tool_button("next", "Следующий (N)", lambda: self._engine.step_playlist(True))

        self._position_label = QLabel("00:00")
        self._duration_label = QLabel("00:00")
        self._seek_slider = SeekSlider()
        self._seek_slider.setRange(0, SEEK_RESOLUTION)
        self._seek_slider.sliderPressed.connect(lambda: setattr(self, "_scrubbing", True))
        self._seek_slider.sliderReleased.connect(lambda: setattr(self, "_scrubbing", False))
        self._seek_slider.sliderMoved.connect(self._on_seek_slider_moved)

        self._subtitles_button = self._tool_button(
            "subtitles", "Субтитры вкл/выкл (C)", self._toggle_subtitles, checkable=True
        )
        self._subtitles_button.setChecked(self._prefs.subtitles_visible)
        self._aspect_button = self._tool_button("aspect", "Растяжка (A)", lambda: self._cycle_aspect())
        self._mute_button = self._tool_button("volume", "Без звука (M)", lambda: self._toggle_mute())
        self._volume_slider = QSlider(Qt.Horizontal)
        self._volume_slider.setRange(0, MAX_VOLUME)
        self._volume_slider.setFixedWidth(92)
        self._volume_slider.setValue(round(self._prefs.volume))
        self._volume_slider.valueChanged.connect(self._on_volume_slider_changed)
        self._panel_button = self._tool_button(
            "panel", "Панель: настройки, история, коллекции (Tab)", lambda: self._panel.toggle(), checkable=True
        )
        self._fullscreen_button = self._tool_button("fullscreen", "Полный экран (F)", self._toggle_fullscreen)

        for widget in (
            self._open_button, self._previous_button, self._play_button, self._next_button,
            self._position_label,
        ):
            row.addWidget(widget)
        row.addWidget(self._seek_slider, 1)
        for widget in (
            self._duration_label, self._subtitles_button, self._aspect_button,
            self._mute_button, self._volume_slider, self._panel_button, self._fullscreen_button,
        ):
            row.addWidget(widget)
        return bar

    @staticmethod
    def _tool_button(
        icon_name: str, tooltip: str, slot: Callable[[], None], checkable: bool = False
    ) -> QToolButton:
        button = QToolButton()
        button.setIcon(icon(icon_name))
        button.setIconSize(_ICON_SIZE)
        button.setToolTip(tooltip)
        button.setCheckable(checkable)
        button.clicked.connect(lambda _checked=False: slot())
        return button

    def _create_engine(self) -> MpvEngine:
        config = EngineConfig(
            volume=self._prefs.volume,
            hdr_index=self._prefs.hdr_index,
            subtitles_visible=self._prefs.subtitles_visible,
            subtitle_scale=self._prefs.subtitle_scale,
            subtitle_autoload=self._prefs.subtitle_autoload,
        )
        return MpvEngine(int(self._video.winId()), config, parent=self)

    def _connect_engine(self) -> None:
        engine = self._engine
        engine.position_changed.connect(self._on_position_changed)
        engine.duration_changed.connect(self._on_duration_changed)
        engine.paused_changed.connect(self._on_paused_changed)
        engine.title_changed.connect(self._on_title_changed)
        engine.tracks_changed.connect(self._panel.settings_page.set_tracks)
        engine.file_loaded.connect(self._on_file_loaded)
        engine.user_command.connect(self._on_engine_command)

    def _connect_panel(self) -> None:
        settings = self._panel.settings_page
        settings.subtitles_visibility_changed.connect(self._set_subtitles_visible)
        settings.subtitle_track_selected.connect(lambda track_id: self._engine.select_subtitle(track_id))
        settings.add_subtitles_requested.connect(self._prompt_add_subtitles)
        settings.subtitle_scale_changed.connect(self._set_subtitle_scale)
        settings.subtitle_delay_changed.connect(lambda seconds: self._engine.set_subtitle_delay(seconds))
        settings.subtitle_autoload_changed.connect(self._set_subtitle_autoload)
        settings.aspect_mode_selected.connect(self._apply_aspect)
        settings.hdr_mode_selected.connect(self._apply_hdr)
        settings.resume_changed.connect(self._set_resume_playback)
        self._panel.history_page.play_requested.connect(lambda path: self.open_files([path]))
        self._panel.collections_page.play_requested.connect(self.open_files)
        self._panel.visibility_changed.connect(self._panel_button.setChecked)

    def _build_action_table(self) -> Dict[Action, Callable[[Optional[float]], None]]:
        engine = self._engine
        return {
            Action.TOGGLE_PAUSE: lambda _arg: engine.toggle_pause(),
            Action.TOGGLE_FULLSCREEN: lambda _arg: self._toggle_fullscreen(),
            Action.EXIT_FULLSCREEN: lambda _arg: self._exit_fullscreen(),
            Action.SEEK: lambda arg: engine.seek_by(arg or 0.0),
            Action.VOLUME: lambda arg: self._nudge_volume(arg or 0.0),
            Action.MUTE: lambda _arg: self._toggle_mute(),
            Action.CYCLE_SUBTITLE: lambda _arg: engine.cycle_subtitle_track(),
            Action.TOGGLE_SUBTITLES: lambda _arg: self._toggle_subtitles(),
            Action.CYCLE_AUDIO: lambda _arg: engine.cycle_audio_track(),
            Action.CYCLE_ASPECT: lambda _arg: self._cycle_aspect(),
            Action.CYCLE_HDR: lambda _arg: self._cycle_hdr(),
            Action.OPEN_FILE: lambda _arg: self._prompt_open_files(),
            Action.OPEN_SUBTITLE: lambda _arg: self._prompt_add_subtitles(),
            Action.SUBTITLE_DELAY: lambda arg: self._nudge_subtitle_delay(arg or 0.0),
            Action.SPEED: lambda arg: engine.show_text(f"Скорость x{engine.change_speed(arg or 1.0):.2f}"),
            Action.RESET_SPEED: lambda _arg: (engine.reset_speed(), engine.show_text("Скорость x1.00")),
            Action.FRAME_STEP: lambda _arg: engine.step_frame(True),
            Action.FRAME_BACK: lambda _arg: engine.step_frame(False),
            Action.NEXT: lambda _arg: engine.step_playlist(True),
            Action.PREVIOUS: lambda _arg: engine.step_playlist(False),
            Action.STATS: lambda _arg: engine.toggle_stats(),
            Action.CONTEXT_MENU: lambda _arg: self._show_context_menu(),
            Action.TOGGLE_PANEL: lambda _arg: self._panel.toggle(),
        }

    def _start_background_services(self) -> None:
        self._cursor_watcher = CursorActivityWatcher(CONTROLS_IDLE_TIMEOUT_MS, self)
        self._cursor_watcher.moved.connect(self._on_cursor_moved)
        self._cursor_watcher.idle.connect(self._on_cursor_idle)
        self._cursor_watcher.start()

        self._progress_timer = QTimer(self)
        self._progress_timer.setInterval(PROGRESS_SAVE_INTERVAL_MS)
        self._progress_timer.timeout.connect(self._persist_progress)
        self._progress_timer.start()

    # ------------------------------------------------------------------
    # Opening media
    # ------------------------------------------------------------------

    def open_files(self, paths: Sequence[str]) -> None:
        playable = [path for path in paths if "://" in path or os.path.exists(path)]
        if not playable:
            return
        self._persist_progress()
        self._engine.load(playable)

    def _prompt_open_files(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(self, "Открыть видео", "", video_file_filter())
        self.open_files(files)

    def _prompt_add_subtitles(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(self, "Добавить субтитры", "", subtitle_file_filter())
        self._attach_subtitles(files)

    def _attach_subtitles(self, files: Sequence[str]) -> None:
        """Adds user-supplied subtitle files and remembers them for this video."""
        if not files:
            return
        for path in files:
            self._engine.add_subtitle(path, select=True)
            if self._current_path:
                self._library.attach_subtitle(self._current_path, path)
        self._library.save()
        self._engine.show_text("Субтитры добавлены")

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:  # noqa: N802 (Qt override)
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event: QDropEvent) -> None:  # noqa: N802 (Qt override)
        dropped = [url.toLocalFile() for url in event.mimeData().urls() if url.isLocalFile()]
        subtitles = [path for path in dropped if path.lower().endswith(SUBTITLE_EXTENSIONS)]
        videos = [path for path in dropped if path not in subtitles]
        if videos:
            self.open_files(videos)
        self._attach_subtitles(subtitles)

    # ------------------------------------------------------------------
    # Engine events
    # ------------------------------------------------------------------

    def _on_file_loaded(self) -> None:
        path = self._engine.current_path
        self._current_path = path
        if not path:
            return
        self._media_title = self._engine.media_title
        entry = self._library.history_entry(path)
        resume_at = 0.0
        if entry is not None:
            self._restore_subtitles(entry.subtitles)
            if self._prefs.resume_playback and entry.is_resumable:
                resume_at = entry.position
                self._engine.seek_to(resume_at)
                self._engine.show_text(f"Продолжено с {format_duration(resume_at)}")
        self._last_position = resume_at
        self._library.record_playback(
            path,
            title=self._media_title or os.path.basename(path),
            position=resume_at,
            duration=entry.duration if entry else 0.0,
        )
        self._panel.settings_page.set_subtitle_delay(self._engine.subtitle_delay)

    def _restore_subtitles(self, subtitles: Sequence[str]) -> None:
        existing = [path for path in subtitles if os.path.exists(path)]
        for index, path in enumerate(existing):
            self._engine.add_subtitle(path, select=index == len(existing) - 1)

    def _on_position_changed(self, seconds: float) -> None:
        self._last_position = seconds
        self._position_label.setText(format_duration(seconds))
        if self._scrubbing or self._duration <= 0:
            return
        self._seek_slider.blockSignals(True)
        self._seek_slider.setValue(int(seconds / self._duration * SEEK_RESOLUTION))
        self._seek_slider.blockSignals(False)

    def _on_duration_changed(self, seconds: float) -> None:
        self._duration = seconds
        self._duration_label.setText(format_duration(seconds))

    def _on_paused_changed(self, paused: bool) -> None:
        self._play_button.setIcon(icon("play" if paused else "pause"))

    def _on_title_changed(self, title: str) -> None:
        self._media_title = title
        self.setWindowTitle(f"{title} — {APP_NAME}" if title else APP_NAME)

    def _on_engine_command(self, name: str, argument: Optional[float]) -> None:
        try:
            action = Action(name)
        except ValueError:
            _log.warning("Ignoring unknown action %r", name)
            return
        handler = self._handlers.get(action)
        if handler is not None:
            handler(argument)

    # ------------------------------------------------------------------
    # Controls
    # ------------------------------------------------------------------

    def _on_seek_slider_moved(self, value: int) -> None:
        if self._duration > 0:
            self._engine.seek_to(value / SEEK_RESOLUTION * self._duration)

    def _on_volume_slider_changed(self, value: int) -> None:
        self._engine.set_volume(value)
        self._prefs.volume = float(value)

    def _nudge_volume(self, delta: float) -> None:
        target = max(0, min(MAX_VOLUME, round(self._engine.volume + delta)))
        self._volume_slider.setValue(target)
        self._engine.show_text(f"Громкость {target}%")

    def _toggle_mute(self) -> None:
        muted = self._engine.toggle_mute()
        self._mute_button.setIcon(icon("volume_off" if muted else "volume"))

    def _toggle_subtitles(self) -> None:
        self._set_subtitles_visible(not self._prefs.subtitles_visible)

    def _set_subtitles_visible(self, visible: bool) -> None:
        self._prefs.subtitles_visible = visible
        self._engine.set_subtitles_visible(visible)
        self._subtitles_button.setChecked(visible)
        self._panel.settings_page.set_subtitles_visible(visible)
        self._engine.show_text("Субтитры включены" if visible else "Субтитры выключены")

    def _set_subtitle_scale(self, scale: float) -> None:
        self._prefs.subtitle_scale = scale
        self._engine.set_subtitle_scale(scale)

    def _set_subtitle_autoload(self, enabled: bool) -> None:
        self._prefs.subtitle_autoload = enabled
        self._engine.set_subtitle_autoload(enabled)

    def _set_resume_playback(self, enabled: bool) -> None:
        self._prefs.resume_playback = enabled

    def _nudge_subtitle_delay(self, delta: float) -> None:
        delay = round(self._engine.subtitle_delay + delta, 2)
        self._engine.set_subtitle_delay(delay)
        self._panel.settings_page.set_subtitle_delay(delay)
        self._engine.show_text(f"Задержка субтитров {delay:+.1f} с")

    def _cycle_aspect(self) -> None:
        self._apply_aspect((self._aspect_index + 1) % len(ASPECT_MODES))

    def _apply_aspect(self, index: int) -> None:
        self._aspect_index = index
        mode = ASPECT_MODES[index]
        self._engine.set_aspect(mode)
        self._panel.settings_page.set_aspect_index(index)
        self._engine.show_text(f"Растяжка: {mode.label}")

    def _cycle_hdr(self) -> None:
        self._apply_hdr((self._prefs.hdr_index + 1) % len(HDR_MODES))

    def _apply_hdr(self, index: int) -> None:
        self._prefs.hdr_index = index
        mode = HDR_MODES[index]
        self._engine.set_hdr(mode)
        self._panel.settings_page.set_hdr_index(index)
        self._engine.show_text(f"HDR: {mode.label}")

    # ------------------------------------------------------------------
    # Fullscreen and auto-hiding controls
    # ------------------------------------------------------------------

    def _toggle_fullscreen(self) -> None:
        if self.isFullScreen():
            self._exit_fullscreen()
            return
        self.showFullScreen()
        self._fullscreen_button.setIcon(icon("fullscreen_exit"))
        self._controls_fader.snap(False)

    def _exit_fullscreen(self) -> None:
        if not self.isFullScreen():
            return
        self.showNormal()
        self._fullscreen_button.setIcon(icon("fullscreen"))
        self._controls_fader.snap(True)

    def _on_cursor_moved(self) -> None:
        if self.isFullScreen() and not self._controls_fader.target_visible:
            self._controls_fader.fade_in()

    def _on_cursor_idle(self) -> None:
        keep_visible = self._controls.underMouse() or self._panel.is_open
        if self.isFullScreen() and not keep_visible:
            self._controls_fader.fade_out()

    # ------------------------------------------------------------------
    # Context menu
    # ------------------------------------------------------------------

    def _show_context_menu(self) -> None:
        menu = QMenu(self)
        menu.addAction("Открыть файл…\tO", self._prompt_open_files)
        menu.addAction("Добавить свои субтитры…\tS", self._prompt_add_subtitles)
        menu.addSeparator()
        self._add_choice_menu(
            menu, "Растяжка (A)", [mode.label for mode in ASPECT_MODES], self._aspect_index, self._apply_aspect
        )
        self._add_choice_menu(
            menu, "HDR / Dolby Vision (H)", [mode.label for mode in HDR_MODES], self._prefs.hdr_index, self._apply_hdr
        )
        self._add_track_menu(menu, "Субтитры (V)", "sub", allow_off=True)
        self._add_track_menu(menu, "Аудиодорожка (B)", "audio", allow_off=False)
        menu.addSeparator()
        menu.addAction("Панель: история и коллекции\tTab", lambda: self._panel.toggle())
        menu.addAction("Статистика\tI", self._engine.toggle_stats)
        menu.addAction("Полный экран\tF", self._toggle_fullscreen)
        menu.addAction("Выход", self.close)
        menu.exec(QCursor.pos())

    @staticmethod
    def _add_choice_menu(
        parent: QMenu, title: str, labels: List[str], current: int, on_select: Callable[[int], None]
    ) -> None:
        submenu = parent.addMenu(title)
        group = QActionGroup(submenu)
        for index, label in enumerate(labels):
            action = submenu.addAction(label)
            action.setCheckable(True)
            action.setChecked(index == current)
            group.addAction(action)
            action.triggered.connect(lambda _checked=False, i=index: on_select(i))

    def _add_track_menu(self, parent: QMenu, title: str, kind: str, allow_off: bool) -> None:
        submenu = parent.addMenu(title)
        tracks: List[Track] = [track for track in self._engine.tracks if track.kind == kind]
        if allow_off:
            submenu.addAction("Выключить", lambda: self._engine.select_subtitle(None))
        for track in tracks:
            action = submenu.addAction(track.label)
            action.setCheckable(True)
            action.setChecked(track.selected)
            if kind == "sub":
                action.triggered.connect(lambda _checked=False, t=track.id: self._engine.select_subtitle(t))
            else:
                action.triggered.connect(lambda _checked=False, t=track.id: self._engine.select_audio(t))

    # ------------------------------------------------------------------
    # Persistence and shutdown
    # ------------------------------------------------------------------

    def _persist_progress(self) -> None:
        if not self._current_path or self._duration <= 0:
            return
        self._library.record_playback(
            self._current_path,
            title=self._media_title or os.path.basename(self._current_path),
            position=self._last_position,
            duration=self._duration,
        )
        self._library.save()
        self._panel.refresh_history()

    def closeEvent(self, event) -> None:  # noqa: N802 (Qt override)
        self._cursor_watcher.stop()
        self._progress_timer.stop()
        self._persist_progress()
        self._prefs.save(self._qsettings)
        self._engine.shutdown()
        super().closeEvent(event)
