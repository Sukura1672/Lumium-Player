"""Lumen Player: a minimal dark video player built on libmpv and Qt."""

__version__ = "1.1.0"
