"""Vector icons rendered from inline SVG (Feather-style, 24x24 grid)."""

from __future__ import annotations

from functools import lru_cache
from typing import Dict

from PySide6.QtCore import QByteArray, Qt
from PySide6.QtGui import QIcon, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer

from .theme import Colors

_DEVICE_PIXEL_RATIO = 2  # Render at 2x so icons stay crisp on HiDPI screens.

# ``{c}`` is replaced by the icon colour for shapes that are filled.
_SHAPES: Dict[str, str] = {
    "play": '<polygon points="7 4 20 12 7 20 7 4" fill="{c}"/>',
    "pause": (
        '<rect x="6" y="4" width="4" height="16" rx="1" fill="{c}"/>'
        '<rect x="14" y="4" width="4" height="16" rx="1" fill="{c}"/>'
    ),
    "previous": '<polygon points="19 20 9 12 19 4 19 20" fill="{c}"/><line x1="5" y1="19" x2="5" y2="5"/>',
    "next": '<polygon points="5 4 15 12 5 20 5 4" fill="{c}"/><line x1="19" y1="5" x2="19" y2="19"/>',
    "folder": '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
    "volume": (
        '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>'
        '<path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/>'
    ),
    "volume_off": (
        '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>'
        '<line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/>'
    ),
    "fullscreen": (
        '<path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/>'
    ),
    "fullscreen_exit": (
        '<path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"/>'
    ),
    "aspect": '<path d="M6.13 1L6 16a2 2 0 0 0 2 2h15"/><path d="M1 6.13L16 6a2 2 0 0 1 2 2v15"/>',
    "subtitles": (
        '<rect x="2" y="5" width="20" height="14" rx="3"/>'
        '<line x1="6" y1="11" x2="10" y2="11"/><line x1="13" y1="11" x2="18" y2="11"/>'
        '<line x1="6" y1="15" x2="12" y2="15"/>'
    ),
    "panel": '<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="15" y1="3" x2="15" y2="21"/>',
    "sliders": (
        '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/>'
        '<line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/>'
        '<line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/>'
        '<line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/>'
        '<line x1="17" y1="16" x2="23" y2="16"/>'
    ),
    "clock": '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    "list": (
        '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/>'
        '<line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/>'
        '<line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>'
    ),
    "plus": '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
    "trash": (
        '<polyline points="3 6 5 6 21 6"/>'
        '<path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>'
    ),
}


def _render(name: str, color: str, size: int) -> QPixmap:
    shapes = _SHAPES[name].replace("{c}", color)
    svg = (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
        f'stroke="{color}" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">'
        f"{shapes}</svg>"
    )
    pixel_size = size * _DEVICE_PIXEL_RATIO
    pixmap = QPixmap(pixel_size, pixel_size)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    QSvgRenderer(QByteArray(svg.encode("utf-8"))).render(painter)
    painter.end()
    pixmap.setDevicePixelRatio(_DEVICE_PIXEL_RATIO)
    return pixmap


@lru_cache(maxsize=None)
def icon(name: str, size: int = 22) -> QIcon:
    """Returns a themed icon with normal, hover and disabled appearances."""
    result = QIcon()
    result.addPixmap(_render(name, Colors.ICON, size), QIcon.Normal)
    result.addPixmap(_render(name, Colors.ICON_ACTIVE, size), QIcon.Active)
    result.addPixmap(_render(name, Colors.ICON_DISABLED, size), QIcon.Disabled)
    return result
