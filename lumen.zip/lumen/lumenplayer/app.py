"""Application bootstrap: logging, Qt setup and graceful startup failures."""

from __future__ import annotations

import ctypes
import logging
import sys
from logging.handlers import RotatingFileHandler
from types import TracebackType
from typing import Optional, Sequence, Type

from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication, QMessageBox

from . import __version__
from .constants import APP_NAME, WINDOWS_APP_ID
from .paths import resource_path, user_data_dir
from .theme import apply_dark_theme

_LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s: %(message)s"
_LOG_MAX_BYTES = 512 * 1024
_LOG_BACKUPS = 2

_log = logging.getLogger(__name__)


def _configure_logging() -> None:
    """Logs to a rotating file; a windowed executable has no console to read."""
    handler = RotatingFileHandler(
        user_data_dir() / "lumen.log",
        maxBytes=_LOG_MAX_BYTES,
        backupCount=_LOG_BACKUPS,
        encoding="utf-8",
    )
    handler.setFormatter(logging.Formatter(_LOG_FORMAT))
    logging.basicConfig(level=logging.INFO, handlers=[handler])

    def log_uncaught(
        exc_type: Type[BaseException],
        exc_value: BaseException,
        exc_traceback: Optional[TracebackType],
    ) -> None:
        _log.critical("Uncaught exception", exc_info=(exc_type, exc_value, exc_traceback))
        sys.__excepthook__(exc_type, exc_value, exc_traceback)

    sys.excepthook = log_uncaught


def _set_windows_app_id() -> None:
    """Gives the process its own taskbar identity so the custom icon is used."""
    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(WINDOWS_APP_ID)
    except (AttributeError, OSError):
        _log.debug("Could not set the AppUserModelID", exc_info=True)


def run(argv: Sequence[str]) -> int:
    """Starts the application and returns the process exit code."""
    _configure_logging()
    _log.info("Starting %s %s", APP_NAME, __version__)
    _set_windows_app_id()

    app = QApplication(list(argv))
    app.setApplicationName(APP_NAME)
    app.setWindowIcon(QIcon(str(resource_path("icon.png"))))
    apply_dark_theme(app)

    try:
        # Imported lazily: loading the window loads libmpv, which may be missing.
        from .window import PlayerWindow

        window = PlayerWindow(argv[1:])
    except (ImportError, OSError) as error:
        _log.exception("Could not initialise the player")
        QMessageBox.critical(
            None,
            APP_NAME,
            "Не удалось загрузить видеодвижок libmpv (mpv-2.dll).\n"
            "Переустановите приложение или положите mpv-2.dll рядом с программой.\n\n"
            f"{error}",
        )
        return 1

    window.show()
    return app.exec()
