"""Unit tests for the persistence layer (no Qt or mpv required)."""

import json
import tempfile
import unittest
from pathlib import Path

from lumenplayer.library import (
    MAX_HISTORY_ENTRIES,
    HistoryEntry,
    Library,
    format_duration,
)


class FormatDurationTest(unittest.TestCase):
    def test_minutes_and_seconds(self) -> None:
        self.assertEqual(format_duration(65), "01:05")

    def test_hours(self) -> None:
        self.assertEqual(format_duration(3725), "1:02:05")

    def test_handles_none_and_negative(self) -> None:
        self.assertEqual(format_duration(None), "00:00")
        self.assertEqual(format_duration(-4), "00:00")


class HistoryEntryTest(unittest.TestCase):
    def test_resumable_in_the_middle(self) -> None:
        self.assertTrue(HistoryEntry("a.mkv", "a", position=600, duration=3600).is_resumable)

    def test_not_resumable_at_the_start_or_the_end(self) -> None:
        self.assertFalse(HistoryEntry("a.mkv", "a", position=2, duration=3600).is_resumable)
        self.assertFalse(HistoryEntry("a.mkv", "a", position=3500, duration=3600).is_resumable)

    def test_not_resumable_without_duration(self) -> None:
        self.assertFalse(HistoryEntry("a.mkv", "a", position=600, duration=0).is_resumable)

    def test_progress_is_clamped(self) -> None:
        self.assertEqual(HistoryEntry("a", "a", position=50, duration=100).progress, 0.5)
        self.assertEqual(HistoryEntry("a", "a", position=500, duration=100).progress, 1.0)


class LibraryTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.file = Path(self._tmp.name) / "library.json"
        self.library = Library(self.file)


class HistoryTest(LibraryTestCase):
    def test_record_and_lookup(self) -> None:
        self.library.record_playback("/v/film.mkv", title="Film", position=120, duration=3600)
        entry = self.library.history_entry("/v/film.mkv")
        self.assertIsNotNone(entry)
        self.assertEqual(entry.position, 120)

    def test_zero_duration_keeps_known_duration(self) -> None:
        self.library.record_playback("/v/a.mkv", title="A", position=10, duration=100)
        self.library.record_playback("/v/a.mkv", title="A", position=20, duration=0)
        self.assertEqual(self.library.history_entry("/v/a.mkv").duration, 100)

    def test_recent_is_ordered_newest_first(self) -> None:
        self.library.record_playback("/v/old.mkv", title="old", position=0, duration=1)
        self.library.history_entry("/v/old.mkv").last_played = 1.0
        self.library.record_playback("/v/new.mkv", title="new", position=0, duration=1)
        self.assertEqual([e.title for e in self.library.recent()], ["new", "old"])

    def test_history_is_trimmed(self) -> None:
        for index in range(MAX_HISTORY_ENTRIES + 5):
            self.library.record_playback(f"/v/{index}.mkv", title=str(index), position=0, duration=1)
        self.assertEqual(len(self.library.recent()), MAX_HISTORY_ENTRIES)

    def test_subtitles_are_attached_once(self) -> None:
        self.library.attach_subtitle("/v/a.mkv", "/s/a.srt")
        self.library.attach_subtitle("/v/a.mkv", "/s/a.srt")
        self.assertEqual(self.library.history_entry("/v/a.mkv").subtitles, ["/s/a.srt"])

    def test_remove_and_clear(self) -> None:
        self.library.record_playback("/v/a.mkv", title="a", position=0, duration=1)
        self.library.record_playback("/v/b.mkv", title="b", position=0, duration=1)
        self.library.remove_history("/v/a.mkv")
        self.assertIsNone(self.library.history_entry("/v/a.mkv"))
        self.library.clear_history()
        self.assertEqual(self.library.recent(), [])


class CollectionsTest(LibraryTestCase):
    def test_create_rejects_blank_and_duplicate(self) -> None:
        self.assertTrue(self.library.create_collection("Anime"))
        self.assertFalse(self.library.create_collection("Anime"))
        self.assertFalse(self.library.create_collection("   "))

    def test_add_deduplicates(self) -> None:
        self.library.create_collection("Mix")
        self.assertEqual(self.library.add_to_collection("Mix", ["/v/a.mkv", "/v/b.mkv"]), 2)
        self.assertEqual(self.library.add_to_collection("Mix", ["/v/a.mkv", "/v/c.mkv"]), 1)
        self.assertEqual(len(self.library.collection_items("Mix")), 3)

    def test_add_to_unknown_collection_is_a_no_op(self) -> None:
        self.assertEqual(self.library.add_to_collection("Nope", ["/v/a.mkv"]), 0)

    def test_remove_item_and_collection(self) -> None:
        self.library.create_collection("Mix")
        self.library.add_to_collection("Mix", ["/v/a.mkv", "/v/b.mkv"])
        self.library.remove_from_collection("Mix", 0)
        self.assertEqual(self.library.collection_items("Mix"), ["/v/b.mkv"])
        self.library.remove_from_collection("Mix", 99)  # Out of range: ignored.
        self.library.delete_collection("Mix")
        self.assertEqual(self.library.collection_names(), [])

    def test_names_are_sorted_case_insensitively(self) -> None:
        for name in ("beta", "Alpha", "gamma"):
            self.library.create_collection(name)
        self.assertEqual(self.library.collection_names(), ["Alpha", "beta", "gamma"])


class PersistenceTest(LibraryTestCase):
    def test_round_trip(self) -> None:
        self.library.record_playback("/v/a.mkv", title="A", position=42, duration=100)
        self.library.attach_subtitle("/v/a.mkv", "/s/a.srt")
        self.library.create_collection("Mix")
        self.library.add_to_collection("Mix", ["/v/a.mkv"])
        self.library.save()

        reloaded = Library(self.file)
        entry = reloaded.history_entry("/v/a.mkv")
        self.assertEqual((entry.title, entry.position, entry.subtitles), ("A", 42, ["/s/a.srt"]))
        self.assertEqual(reloaded.collection_items("Mix"), ["/v/a.mkv"])

    def test_corrupt_file_is_quarantined(self) -> None:
        self.file.write_text("{ definitely not json", encoding="utf-8")
        reloaded = Library(self.file)
        self.assertEqual(reloaded.recent(), [])
        self.assertTrue(self.file.with_suffix(".corrupt").exists())

    def test_wrong_shape_is_quarantined(self) -> None:
        self.file.write_text(json.dumps({"history": [{"no_path": 1}]}), encoding="utf-8")
        self.assertEqual(Library(self.file).recent(), [])

    def test_save_leaves_no_temporary_file(self) -> None:
        self.library.save()
        self.assertFalse(self.file.with_suffix(".tmp").exists())


if __name__ == "__main__":
    unittest.main()
