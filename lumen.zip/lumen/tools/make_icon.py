"""Generates ``icon.png`` and ``icon.ico`` (requires Pillow).

Usage: ``python tools/make_icon.py`` from the project root.
"""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageOps

CANVAS = 1024
CORNER_RADIUS = 230
ICO_SIZES = [(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]

BACKGROUND_TOP = (40, 46, 78)
BACKGROUND_BOTTOM = (13, 14, 22)
PLAY_START = (124, 156, 255)
PLAY_END = (190, 156, 255)


def _gradient(size: int, start: tuple, end: tuple, diagonal: bool = False) -> Image.Image:
    ramp = Image.linear_gradient("L").resize((size, size))
    if diagonal:
        ramp = ImageChops.add(
            ramp.point(lambda v: v // 2),
            ramp.transpose(Image.Transpose.ROTATE_270).point(lambda v: v // 2),
        )
    return ImageOps.colorize(ramp, black=start, white=end).convert("RGBA")


def _rounded_mask(size: int, radius: int) -> Image.Image:
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, size - 1, size - 1), radius=radius, fill=255)
    return mask


def _play_triangle_mask(size: int) -> Image.Image:
    """A play triangle with softly rounded corners, optically centred."""
    cx, cy = size * 0.53, size * 0.5
    half_h, width = size * 0.22, size * 0.40
    points = [
        (cx - width * 0.45, cy - half_h),
        (cx - width * 0.45, cy + half_h),
        (cx + width * 0.55, cy),
    ]
    mask = Image.new("L", (size, size), 0)
    draw = ImageDraw.Draw(mask)
    draw.polygon(points, fill=255)
    draw.line(points + [points[0]], fill=255, width=int(size * 0.07), joint="curve")
    for x, y in points:
        radius = size * 0.035
        draw.ellipse((x - radius, y - radius, x + radius, y + radius), fill=255)
    return mask


def build_icon() -> Image.Image:
    canvas = _gradient(CANVAS, BACKGROUND_TOP, BACKGROUND_BOTTOM)

    glow = Image.new("RGBA", (CANVAS, CANVAS), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse(
        (CANVAS * 0.18, CANVAS * 0.18, CANVAS * 0.82, CANVAS * 0.82), fill=(124, 156, 255, 90)
    )
    canvas = Image.alpha_composite(canvas, glow.filter(ImageFilter.GaussianBlur(CANVAS * 0.09)))

    triangle = _gradient(CANVAS, PLAY_START, PLAY_END, diagonal=True)
    canvas.paste(triangle, (0, 0), _play_triangle_mask(CANVAS))

    border = Image.new("RGBA", (CANVAS, CANVAS), (0, 0, 0, 0))
    ImageDraw.Draw(border).rounded_rectangle(
        (6, 6, CANVAS - 7, CANVAS - 7), radius=CORNER_RADIUS, outline=(255, 255, 255, 38), width=6
    )
    canvas = Image.alpha_composite(canvas, border)

    result = Image.new("RGBA", (CANVAS, CANVAS), (0, 0, 0, 0))
    result.paste(canvas, (0, 0), _rounded_mask(CANVAS, CORNER_RADIUS))
    return result


def main() -> None:
    root = Path(__file__).resolve().parent.parent
    icon = build_icon()
    icon.resize((256, 256), Image.Resampling.LANCZOS).save(root / "icon.png")
    icon.save(root / "icon.ico", sizes=ICO_SIZES)
    print("Wrote icon.png and icon.ico")


if __name__ == "__main__":
    main()
